/*****************************************************************
//
//  NAME:        Adriel White
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        April 24, 2023
//
//  FILE:        user_interface.c
//
//  DESCRIPTION:
//   User Interface that controls interactions and gets inputs
//   while using a llist object to modify and access a database.
//
****************************************************************/

#include <cstring>
#include <iostream>
#include <fstream>
#include "record.h"
#include "llist.h"

using namespace std;

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   Generates menu and gets user input to modify
//                 database.
//
//  Parameters:    argc (int) : The number of elements in argv
//                 argv (char*[]) : An array of arguments passed
//                                  to the program.
//
//  Return values:  0 : success
//
****************************************************************/

int main(int argc, char* argv[])
{
    int quit = -1;
    char choice[20];
    int int_input;
    char str_input[40];
    char address[50];
    char temp[50];
    int result;
    int allocated;

    llist mylist;

    cout << "\nThis program houses a database of records containing:";
    cout << " name, account numbers, and addresses.";
    do
    {
        cout << "\nMenu --> choose an option (by typing it)";
        cout << "\nadd: creates a new record";
        cout << "\nprintall: Prints all records in the database";
        cout << "\nfind: Find record(s) with a specified account #";
        cout << "\ndelete: Delete existing record(s) from ";
        cout << "database using account # as a key";
        cout << "\nquit: Exit the program";

        cout << "\n\nEnter your choice: ";
        choice[19] = 'a';
        cin.getline(choice, 20);
        if (strncmp("quit", choice, strlen(choice)) == 0)
        {
            quit = 0;
        }
        else if (strncmp("find", choice, strlen(choice)) == 0)
        {
            int_input = -1;
            while (int_input < 1)
            {
                cout << "\nEnter the account number you would like to search for: ";
                cin >> int_input;
                cin.clear();
                cin.ignore(80, '\n');
                if (int_input < 1)
                {
                    cout << "\nInvalid input. Account number must be a positive integer";
                }
            }
            result = mylist.findRecord(int_input);
            if (result == -1)
            {
                cout << "\nNo record was found with that account number.\n";
            }
            else
            {
                cout <<"\n" << result << " record(s) found and printed above.\n";
            }
        }
        else if (strncmp("delete", choice, strlen(choice)) == 0)
        {
            int_input = -1;
            while (int_input < 1)
            {
                cout << "\nEnter the account number of the ";
                cout << "record you would like to delete: ";
                cin >> int_input;
                if (int_input < 1)
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cout << "\nInvalid input. Account number must be a positive integer";
                }
            }
            cin.clear();
            cin.ignore(80, '\n');
            result = mylist.deleteRecord(int_input);
            if (result == -1)
            {
                cout << "\nNo record was found with that account number.\n";
            }
            else
            {
                cout << "\n" << result << " record(s) deleted.\n";
            }
        }
        else if (strncmp("printall", choice, strlen(choice)) == 0)
        {
            cout << mylist;
        }
        else if (strncmp("add", choice, strlen(choice)) == 0)
        {
            int_input = -1;
            while (int_input < 1)
            {
                cout << "\nEnter the new account number: ";
                cin >> int_input;
                if (int_input < 1)
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cout << "\nInvalid input. Account number must be a positive integer";
                }
            }
            cin.clear();
            cin.ignore(40, '\n');
            str_input[0] = '\0';
            while (str_input[0] == '\0')
            {
                cout << "\nEnter the new name: ";
                str_input[29] = 'a';
                cin.getline(str_input, 30);
                if (str_input[0] == '\0')
                {
                    cout << "\nInvalid input. Enter string";
                }
                if (str_input[29] == '\0')
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    str_input[28] = '\n';
                }
                else
                {
                    strcat(str_input, "\n");
                }
            }
            cout << "\nEnter the new address (can be multiple lines, press";
            cout << " Enter on an empty line to complete):\n";
            address[49] = 'z';
            address[0] = '\0';
            strcpy(temp, "not empty");
            allocated = 0;
            while (strlen(temp) != 0 && address[49] == 'z')
            {
                cin.getline(temp, (49-allocated));
                allocated += strlen(temp);
                strcat(address, temp);
                strcat(address, "\n");
            }
            if (address[49] == '\0')
            {
                address[48] = '\n';
            }
            if (allocated > 47)
            {
                cin.clear();
                cin.ignore(160, '\n');
            }
            mylist.addRecord(int_input, str_input, address);
            cout << "\nRecord successfully added\n";
        }
        else
        {
            cout << "\nInvalid choice. Enter a keyword below.";
            cin.clear();
            if (choice[19] == '\0')
            {
                cin.ignore(80, '\n');
            }
        }
    }
    while (quit == -1);

    return 0;
}
