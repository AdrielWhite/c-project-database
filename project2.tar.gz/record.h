/*****************************************************************
//
//  NAME:        Adriel White
//
//  HOMEWORK:    3
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        February 10, 2023
//
//  FILE:        record.h
//
//  DESCRIPTION:
//   Defines a struct that will hold account info for a person.
//
****************************************************************/

#ifndef RECORD_H
#define RECORD_H

struct record
{
    int                 accountno;
    char                name[30];
    char                address[50];
    struct record*      next;
};
#endif
