/*****************************************************************
//
//  NAME:        Adriel White
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        April 17, 2023
//
//  FILE:        llist.h
//
//  DESCRIPTION:
//   Defines the class that will be the linked list that contains
//   the database.
//
****************************************************************/

#ifndef LLIST_H
#define LLIST_H

using namespace std;

class llist
{
private:
    record * start;
    char filename[20];
    int readfile();
    int writefile();
    void cleanup();

public:
    llist();
    llist(char[]);
    llist(llist&);
    llist& operator=(const llist&);
    ~llist();
    void addRecord(int, char[], char[]);
    int findRecord(int);
    void printAllRecords();
    int deleteRecord(int);
    friend ostream& operator<<(ostream&, const llist&);
};
#endif
