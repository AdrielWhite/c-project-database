/*****************************************************************
//
//  NAME:        Adriel White
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        April 17, 2023
//
//  FILE:        llist.cpp
//
//  DESCRIPTION:
//   llist class functions which provide database functionality
//
****************************************************************/

#include <cstring>
#include <iostream>
#include <fstream>
#include "record.h"
#include "llist.h"

using namespace std;

/****************************************************************
//  Function name:   llist
//
//  DESCRIPTION:   Generic constructor which sets start to NULL
//                 and calls readfile to initialize the database.
//
//  Parameters:    none
//
//  Return values: none
//
****************************************************************/

llist::llist()
{
    int result;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** llist() */";
    #endif
    this->start = NULL;
    strcpy(this->filename, "record_storage.txt");
    result = this->readfile();
    if (result == -1)
    {
        cout << "\nData not loaded:\n1) No records exist OR";
        cout << "\n2) Stored data not properly accessed\n";
    }
}

/****************************************************************
//  Function name:   llist
//
//  DESCRIPTION:   Constructor which sets start to NULL and calls 
//                 readfile (from a file with filename) to 
//                 initialize the database.
//
//  Parameters:    char * filename : name of the file that houses
//                                   the database
//
//  Return values: none
//
****************************************************************/

llist::llist(char * filename)
{
    int result;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** llist() */";
    cout << "\n/* DEBUG ** filename = \"" << filename << "\" */";
    #endif
    this->start = NULL;
    strcpy(this->filename, filename);
    result = this->readfile();
    if (result == -1)
    {
        cout << "\nData not loaded:\n1) No records exist OR";
        cout << "\n2) Stored data not properly accessed\n";
    }
}

/****************************************************************
//  Function name:   llist
//
//  DESCRIPTION:   Copy constructor which copies data from an
//                 existing llist into a new llist object.
//
//  Parameters:    llist &sourcelist : list that is being copied 
//                                     from
//
//  Return values: none
//
****************************************************************/

llist::llist(llist &sourcelist)
{
    int accountno;
    char name[40];
    char address[50];
    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** llist(llist&) */";
    #endif

    record * current = sourcelist.start;

    this->cleanup();
    this->start = NULL;
    strcpy(this->filename, sourcelist.filename);
    while (current != NULL)
    {
        accountno = (*current).accountno;
        strcpy(name, (*current).name);
        strcpy(address, (*current).address);
        current = (*current).next;
        this->addRecord(accountno, name, address);
    }
}

/****************************************************************
//  Function name:   operator=()
//
//  DESCRIPTION:   Assignment overload which copies data from an
//                 existing llist into a another llist object.
//
//  Parameters:    llist& sourcelist : list that is being copied 
//                                     from
//
//  Return values: llist& value that will be a new llist object
//
****************************************************************/

llist& llist::operator=(const llist &sourcelist)
{
    int accountno;
    char name[40];
    char address[50];
    llist returnlist;
    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** llist& operator=(const llist&) */";
    #endif

    record * current = sourcelist.start;

    this->cleanup();
    this->start = NULL;
    strcpy(this->filename, sourcelist.filename);
    while (current != NULL)
    {
        accountno = (*current).accountno;
        strcpy(name, (*current).name);
        strcpy(address, (*current).address);
        current = (*current).next;
        this->addRecord(accountno, name, address);
    }
    return *this;
}

/****************************************************************
//  Function name:   ~llist
//
//  DESCRIPTION:   Deconstructor which calls methods to deallocate
//                 data stored on the HEAP.
//
//  Parameters:    none
//
//  Return values: none
//
****************************************************************/

llist::~llist()
{
    int result;
    result = this->writefile();
    if (result == -1)
    {
        cout << "\nDatabase not successfully stored\n";
    }
    this->cleanup();
}

/*****************************************************************
//
//  Function name:   addRecord
//
//  DESCRIPTION:   Adds a record to the database.
//
//  Parameters:    int uaccountno : user's account number
//                 char[] uname : user's name
//                 char [] uaddress : user's address
//
//  Return values:  none
//
****************************************************************/

void llist::addRecord(int uaccountno, char* uname, char* uaddress)
{
    struct record * newRecord;
    struct record * current;
    struct record * previous;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** addRecord() */";
    cout << "\n/* DEBUG ** accountno = " << uaccountno << " */";
    cout << "\n/* DEBUG ** name = \"" << uname << "\" */";
    cout << "\n/* DEBUG ** address = \"" << uaddress << "\" */" << endl;
    #endif

    newRecord = new struct record();
    (*newRecord).accountno = uaccountno;
    strcpy((*newRecord).name, uname);
    strcpy((*newRecord).address,  uaddress);
    (*newRecord).next = NULL;

    current = this->start;
    previous = NULL;

    if (this->start == NULL)
    {
        this->start = newRecord;
    }
    else
    {
        while (current != NULL && (*newRecord).accountno > (*current).accountno)
        {
            previous = current;
            current = (*current).next;
        }
        if (current == NULL)
        {
            (*previous).next = newRecord;
        }
        else
        {
            (*newRecord).next = current;
            if (previous == NULL)
            {
                this->start = newRecord;
            }
            else
            {
                (*previous).next = newRecord;
            }
        }
    }
}

/****************************************************************
//  Function name:   printAllRecords
//
//  DESCRIPTION:   Prints all records in llist's databse.
//
//  Parameters:    none
//
//  Return values: none
//
****************************************************************/

void llist::printAllRecords()
{
    struct record * current;
    int i;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** printAllRecords() */" << endl;
    #endif

    current = this->start;
    i = 1;
    if (current == NULL)
    {
        cout << "\nNo records exist." << endl;
    }
    while (current != NULL)
    {
        cout << "\nRecord " << i;
        cout << "\naccountno: " << (*current).accountno;
        cout << "\nname: " << (*current).name;
        cout << "address: \n" << (*current).address;

        current = (*current).next;
        i++;
    }
}

/****************************************************************
//  Function name: operator<<
//
//  DESCRIPTION:   Prints all records in llist's databse.
//
//  Parameters:    ostream& ost : output stream that is printed to
//                 const llist& sourcelist : llist that's database
//                                           is printed
//
//  Return values: ost : stream with printed information
//
****************************************************************/

ostream& operator<<(ostream& ost, const llist &sourcelist)
{
    struct record * current;
    int i;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** operator<<(ostream&, const llist&) */" << endl;
    #endif

    current = sourcelist.start;
    i = 1;
    if (current == NULL)
    {
        ost << "\nNo records exist." << endl;
    }
    while (current != NULL)
    {
        ost << "\nRecord " << i;
        ost << "\naccountno: " << (*current).accountno;
        ost << "\nname: " << (*current).name;
        ost << "address: \n" << (*current).address;

        current = (*current).next;
        i++;
    }
    return ost;
}

/****************************************************************
//  Function name:   findRecord
//
//  DESCRIPTION:   Finds record based on target account number.
//
//  Parameters:    int uaccountno : address of the target record
//
//  Return values: -1: no records found
//                 >0: number of records found 
//
****************************************************************/

int llist::findRecord(int uaccountno)
{
    struct record * current;
    int retVal;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** findRecord() */";
    cout << "\n/* DEBUG ** accountno = " << uaccountno << " */\n";
    #endif

    current = this->start;
    retVal = -1;
    while (current != NULL)
    {
        if ((*current).accountno == uaccountno)
        {
            if (retVal < 0)
            {
                retVal = 1;
            }
            else
            {
                retVal++;
            }
            cout << "\naccountno: " << (*current).accountno;
            cout << "\nname: " << (*current).name;
            cout << "address: \n" << (*current).address;
        }
        current = (*current).next;
    }
    return retVal;
}

/****************************************************************
//  Function name:   deleteRecord
//
//  DESCRIPTION:   Deletes the record that has a specific account
//                 number.
//
//  Parameters:    int uaccountno : target address of record to
//                                  delete
//
//  Return values:  -1: no records deleted
//                  >0: number of records deleted
//
****************************************************************/

int llist::deleteRecord(int uaccountno)
{
    struct record * current;
    struct record * previous;
    int retVal;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** deleteRecord */";
    cout << "\n/* DEBUG ** accountno = " << uaccountno << " */\n";
    #endif

    retVal = -1;
    current = this->start;
    previous = NULL;

    while (current != NULL)
    {
        if ((*current).accountno == uaccountno)
        {
            if (retVal < 0)
            {
                retVal = 1;
            }
            else
            {
                retVal++;
            }
            current = (*current).next;
            if (previous == NULL)
            {
                delete this->start;
                this->start = current;
            }
            else
            {
                delete (*previous).next;
                (*previous).next = current;
            }
        }
        else
        {
            previous = current;
            current = (*current).next;
        }
    }

    return retVal;
}

/****************************************************************
//  Function name:   readfile
//
//  DESCRIPTION:   Reads the stored database of records in a txt
//                 file into a linked list
//
//  Parameters:    none
//
//  Return values:  -1: error in opening file
//                   0: success
//
****************************************************************/

int llist::readfile()
{
    int retVal;
    int faccountno;
    char fname[30];
    char faddress[50];
    char ftemp[50];

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** readfile() */";
    #endif

    retVal = 0;
    ifstream fin(filename, ifstream::in);
    if (!fin.is_open())
    {
        retVal = -1;
    }
    else
    {
        while (fin >> faccountno)
        {
            fin.clear();
            fin.ignore(80, '\n');
            fin.getline(fname, 30);
            strcat(fname, "\n");
            faddress[0] = '\0';
            strcpy(ftemp, "not empty");
            while (strlen(ftemp) != 0)
            {
                fin.getline(ftemp, 50);
                strcat(faddress, ftemp);
                strcat(faddress, "\n");
            }
            fin.clear();
            fin.ignore(80, '\n');
            this->addRecord(faccountno, fname, faddress);
        }
        fin.close();
    }

    return retVal;
}

/****************************************************************
//  Function name:   writeFile
//
//  DESCRIPTION:   Stores all records in the database into a txt
//                 file
//
//  Parameters:    none
//                                         
//  Return values: 0 : success
//                 -1 : file not successfully opened
//
****************************************************************/

int llist::writefile()
{
    struct record * current;
    int retVal;

    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** writefile() */";
    #endif

    retVal = 0;
    ofstream fout(this->filename, ofstream::out);
    if (!fout.is_open())
    {
        retVal = -1;
    }
    else
    {
        current = this->start;
        while (current != NULL)
        {
            fout << (*current).accountno << "\n";
            fout << (*current).name;
            fout << (*current).address << "\n";

            current = (*current).next;
        }
        fout.close();
    }

    return retVal;
}

/****************************************************************
//  Function name:   cleanup
//
//  DESCRIPTION:   Releases allocated space and sets start to
//                 NULL
//
//  Parameters:    none
//
//  Return values: none
//
****************************************************************/

void llist::cleanup()
{
    struct record * temp;
    #ifdef DEBUGMODE
    cout << "\n/* DEBUG ** cleanup() */\n\n";
    #endif

    while (this->start != NULL)
    {
        temp = (*this->start).next;
        delete this->start;
        this->start = temp;
    }
}
